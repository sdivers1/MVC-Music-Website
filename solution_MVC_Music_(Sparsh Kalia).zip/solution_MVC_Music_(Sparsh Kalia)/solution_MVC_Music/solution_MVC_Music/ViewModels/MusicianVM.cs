﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace solution_MVC_Music.ViewModels
{
    public class MusicianVM
    {
        public int MusicianID { get; set; }
        public string MusicianName { get; set; }
    }
}
