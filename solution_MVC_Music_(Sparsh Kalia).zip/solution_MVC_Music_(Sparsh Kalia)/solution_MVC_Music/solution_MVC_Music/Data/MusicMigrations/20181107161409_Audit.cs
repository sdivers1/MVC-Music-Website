﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace solution_MVC_Music.Data.MusicMigrations
{
    public partial class Audit : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CreatedBy",
                schema: "MUSIC",
                table: "Musicians",
                maxLength: 256,
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedOn",
                schema: "MUSIC",
                table: "Musicians",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "UpdatedBy",
                schema: "MUSIC",
                table: "Musicians",
                maxLength: 256,
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "UpdatedOn",
                schema: "MUSIC",
                table: "Musicians",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CreatedBy",
                schema: "MUSIC",
                table: "Albums",
                maxLength: 256,
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedOn",
                schema: "MUSIC",
                table: "Albums",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "UpdatedBy",
                schema: "MUSIC",
                table: "Albums",
                maxLength: 256,
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "UpdatedOn",
                schema: "MUSIC",
                table: "Albums",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CreatedBy",
                schema: "MUSIC",
                table: "Musicians");

            migrationBuilder.DropColumn(
                name: "CreatedOn",
                schema: "MUSIC",
                table: "Musicians");

            migrationBuilder.DropColumn(
                name: "UpdatedBy",
                schema: "MUSIC",
                table: "Musicians");

            migrationBuilder.DropColumn(
                name: "UpdatedOn",
                schema: "MUSIC",
                table: "Musicians");

            migrationBuilder.DropColumn(
                name: "CreatedBy",
                schema: "MUSIC",
                table: "Albums");

            migrationBuilder.DropColumn(
                name: "CreatedOn",
                schema: "MUSIC",
                table: "Albums");

            migrationBuilder.DropColumn(
                name: "UpdatedBy",
                schema: "MUSIC",
                table: "Albums");

            migrationBuilder.DropColumn(
                name: "UpdatedOn",
                schema: "MUSIC",
                table: "Albums");
        }
    }
}
